using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Threading;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Diagnostics;

namespace CSharpAnalyzers
{
    [DiagnosticAnalyzer(LanguageNames.CSharp)]
    public class CSharpAnalyzersAnalyzer : DiagnosticAnalyzer
    {
        public const string DiagnosticId = "CSharpAnalyzers";

        private static readonly LocalizableString Title = new LocalizableResourceString(nameof(Resources.AnalyzerTitle), Resources.ResourceManager, typeof(Resources));
        private static readonly LocalizableString MessageFormat = new LocalizableResourceString(nameof(Resources.AnalyzerMessageFormat), Resources.ResourceManager, typeof(Resources));
        private static readonly LocalizableString Description = new LocalizableResourceString(nameof(Resources.AnalyzerDescription), Resources.ResourceManager, typeof(Resources));
        private const string Category = "Samples";

        private static DiagnosticDescriptor Rule = new DiagnosticDescriptor(DiagnosticId, Title, MessageFormat, Category, DiagnosticSeverity.Warning, isEnabledByDefault: true, description: Description);

        public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics { get { return ImmutableArray.Create(Rule); } }

        public override void Initialize(AnalysisContext context)
        {
            context.RegisterCompilationStartAction(compilationContext =>
            {
                // Check if the attribute type marking insecure methods is defined.
                var insecureMethodAttributeType = compilationContext.Compilation.GetTypeByMetadataName("MyNamespace.InsecureMethodAttribute");
                if (insecureMethodAttributeType == null)
                {
                    return;
                }

                // Check if the interface type marking secure types is defined.
                var secureTypeInterfaceType = compilationContext.Compilation.GetTypeByMetadataName("MyNamespace.ISecureType");
                if (secureTypeInterfaceType == null)
                {
                    return;
                }

                // Initialize state in the start action.
                var analyzer = new CompilationAnalyzer(insecureMethodAttributeType, secureTypeInterfaceType);

                // Register an intermediate non-end action that accesses and modifies the state.
                compilationContext.RegisterSymbolAction(analyzer.AnalyzeSymbol, SymbolKind.NamedType, SymbolKind.Method);

                // Register an end action to report diagnostics based on the final state.
                compilationContext.RegisterCompilationEndAction(analyzer.CompilationEndAction);
            });
        }

        private class CompilationAnalyzer
        {
            #region Per-Compilation immutable state
            private readonly INamedTypeSymbol _insecureMethodAttributeType;
            private readonly INamedTypeSymbol _secureTypeInterfaceType;
            #endregion

            #region Per-Compilation mutable state
            /// <summary>
            /// List of secure types in the compilation implementing secure interface.
            /// </summary>
            private List<INamedTypeSymbol> _secureTypes;

            /// <summary>
            /// Set of insecure interface types in the compilation that have methods with an insecure method attribute.
            /// </summary>
            private HashSet<INamedTypeSymbol> _interfacesWithInsecureMethods;
            #endregion

            #region State intialization
            public CompilationAnalyzer(INamedTypeSymbol insecureMethodAttributeType, INamedTypeSymbol secureTypeInterfaceType)
            {
                _insecureMethodAttributeType = insecureMethodAttributeType;
                _secureTypeInterfaceType = secureTypeInterfaceType;

                _secureTypes = null;
                _interfacesWithInsecureMethods = null;
            }
            #endregion

            #region Intermediate actions
            public void AnalyzeSymbol(SymbolAnalysisContext context)
            {
                switch (context.Symbol.Kind)
                {
                    case SymbolKind.NamedType:
                        // Check if the symbol implements "_secureTypeInterfaceType".
                        var namedType = (INamedTypeSymbol)context.Symbol;
                        if (namedType.AllInterfaces.Contains(_secureTypeInterfaceType))
                        {
                            _secureTypes = _secureTypes ?? new List<INamedTypeSymbol>();
                            _secureTypes.Add(namedType);
                        }

                        break;

                    case SymbolKind.Method:
                        // Check if this is an interface method with "_insecureMethodAttributeType" attribute.
                        var method = (IMethodSymbol)context.Symbol;
                        if (method.ContainingType.TypeKind == TypeKind.Interface && method.GetAttributes().Any(a => a.AttributeClass.Equals(_insecureMethodAttributeType)))
                        {
                            _interfacesWithInsecureMethods = _interfacesWithInsecureMethods ?? new HashSet<INamedTypeSymbol>();
                            _interfacesWithInsecureMethods.Add(method.ContainingType);
                        }

                        break;
                }
            }
            #endregion

            #region End action
            public void CompilationEndAction(CompilationAnalysisContext context)
            {
                if (_interfacesWithInsecureMethods == null || _secureTypes == null)
                {
                    // No violating types.
                    return;
                }

                // Report diagnostic for violating named types.
                foreach (var secureType in _secureTypes)
                {
                    foreach (var insecureInterface in _interfacesWithInsecureMethods)
                    {
                        if (secureType.AllInterfaces.Contains(insecureInterface))
                        {
                            var diagnostic = Diagnostic.Create(Rule, secureType.Locations[0], secureType.Name, "MyNamespace.ISecureType", insecureInterface.Name);
                            context.ReportDiagnostic(diagnostic);

                            break;
                        }
                    }
                }
            }
            #endregion
        }
    }
}
