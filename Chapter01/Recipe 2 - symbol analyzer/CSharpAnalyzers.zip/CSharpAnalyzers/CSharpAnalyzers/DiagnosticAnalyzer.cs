using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Threading;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Diagnostics;

namespace CSharpAnalyzers
{
    [DiagnosticAnalyzer(LanguageNames.CSharp)]
    public class CSharpAnalyzersAnalyzer : DiagnosticAnalyzer
    {
        public const string DiagnosticId = "CSharpAnalyzers";

        private static readonly LocalizableString Title = new LocalizableResourceString(nameof(Resources.AnalyzerTitle), Resources.ResourceManager, typeof(Resources));
        private static readonly LocalizableString MessageFormat = new LocalizableResourceString(nameof(Resources.AnalyzerMessageFormat), Resources.ResourceManager, typeof(Resources));
        private static readonly LocalizableString Description = new LocalizableResourceString(nameof(Resources.AnalyzerDescription), Resources.ResourceManager, typeof(Resources));
        private const string Category = "Samples";

        private static DiagnosticDescriptor Rule = new DiagnosticDescriptor(DiagnosticId, Title, MessageFormat, Category, DiagnosticSeverity.Warning, isEnabledByDefault: true, description: Description);

        public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics { get { return ImmutableArray.Create(Rule); } }

        public override void Initialize(AnalysisContext context)
        {
            context.RegisterSymbolAction(symbolContext =>
            {
                var symbolName = symbolContext.Symbol.Name;

                // Skip the immediate containing type, CS0542 already covers this case.
                var outerType = symbolContext.Symbol.ContainingType?.ContainingType;
                while (outerType != null)
                {
                    // Check if the current outer type has the same name as the given member.
                    if (symbolName.Equals(outerType.Name))
                    {
                        // For all such symbols, report a diagnostic.
                        var diagnostic = Diagnostic.Create(Rule, symbolContext.Symbol.Locations[0], symbolContext.Symbol.Name);
                        symbolContext.ReportDiagnostic(diagnostic);
                        return;
                    }

                    outerType = outerType.ContainingType;
                }
            },
            SymbolKind.NamedType,
            SymbolKind.Method,
            SymbolKind.Field,
            SymbolKind.Event,
            SymbolKind.Property);
        }
    }
}
