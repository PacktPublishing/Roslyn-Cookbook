﻿public class Class1
{
    public class Class2
    {
    }
}


public class Class3
{
}