﻿using System.Collections.Generic;
using System.Collections.Immutable;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CodeFixes;
using Microsoft.CodeAnalysis.CodeActions;

namespace CSharpAnalyzers
{
    public class CustomFixAllProvider : FixAllProvider
    {
        public override async Task<CodeAction> GetFixAsync(FixAllContext fixAllContext)
        {
            var diagnosticsToFix = new List<KeyValuePair<Document, ImmutableArray<Diagnostic>>>();
            string titleFormat = "Remove all unused locals in {0} {1}";
            string title = null;
            var documentsToFix = ImmutableArray<Document>.Empty;

            switch (fixAllContext.Scope)
            {
                case FixAllScope.Document:
                    {
                        documentsToFix = ImmutableArray.Create(fixAllContext.Document);
                        title = string.Format(titleFormat, "document", fixAllContext.Document.Name);
                        break;
                    }

                case FixAllScope.Project:
                    {
                        documentsToFix = fixAllContext.Project.Documents.ToImmutableArray();
                        title = string.Format(titleFormat, "project", fixAllContext.Project.Name);
                        break;
                    }

                case FixAllScope.Solution:
                    {
                        foreach (Project project in fixAllContext.Solution.Projects)
                        {
                            documentsToFix = documentsToFix.AddRange(project.Documents);
                        }

                        title = "Add all items in the solution to the public API";
                        break;
                    }

                case FixAllScope.Custom:
                    return null;
                default:
                    break;
            }

            foreach (Document document in documentsToFix)
            {
                ImmutableArray<Diagnostic> diagnostics = await fixAllContext.GetDocumentDiagnosticsAsync(document).ConfigureAwait(false);
                diagnosticsToFix.Add(new KeyValuePair<Document, ImmutableArray<Diagnostic>>(document, diagnostics));
            }

            return new CustomFixAllCodeAction(title, fixAllContext.Solution, diagnosticsToFix);
        }
    }
}