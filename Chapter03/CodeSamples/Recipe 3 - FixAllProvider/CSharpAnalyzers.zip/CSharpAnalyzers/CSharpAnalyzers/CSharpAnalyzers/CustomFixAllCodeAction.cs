﻿using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CodeActions;
using System.Threading;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Editing;

namespace CSharpAnalyzers
{
    public class CustomFixAllCodeAction : CodeAction
    {
        private readonly List<KeyValuePair<Document, ImmutableArray<Diagnostic>>> _diagnosticsToFix;
        private readonly Solution _solution;

        public CustomFixAllCodeAction(string title, Solution solution, List<KeyValuePair<Document, ImmutableArray<Diagnostic>>> diagnosticsToFix)
        {
            this.Title = title;
            _solution = solution;
            _diagnosticsToFix = diagnosticsToFix;
        }

        public override string Title { get; }

        protected override async Task<Solution> GetChangedSolutionAsync(CancellationToken cancellationToken)
        {
            var nodesToRemoveMap = new Dictionary<Document, HashSet<SyntaxNode>>();
            foreach (KeyValuePair<Document, ImmutableArray<Diagnostic>> pair in _diagnosticsToFix)
            {
                Document document = pair.Key;
                ImmutableArray<Diagnostic> diagnostics = pair.Value;
                var nodesToRemove = new HashSet<SyntaxNode>();
                foreach (var diagnostic in diagnostics)
                {
                    var nodeToRemove = await CSharpAnalyzersCodeFixProvider.GetNodeToRemoveAsync(document, diagnostic, cancellationToken).ConfigureAwait(false);
                    if (nodeToRemove != null)
                    {
                        nodesToRemove.Add(nodeToRemove);
                    }
                }

                var candidateLocalDeclarationsToRemove = new HashSet<LocalDeclarationStatementSyntax>();
                foreach (var variableDeclarator in nodesToRemove.OfType<VariableDeclaratorSyntax>())
                {
                    var localDeclaration = (LocalDeclarationStatementSyntax)variableDeclarator.Parent.Parent;
                    candidateLocalDeclarationsToRemove.Add(localDeclaration);
                }

                foreach (var candidate in candidateLocalDeclarationsToRemove)
                {
                    var hasUsedLocal = false;
                    foreach (var variable in candidate.Declaration.Variables)
                    {
                        if (!nodesToRemove.Contains(variable))
                        {
                            hasUsedLocal = true;
                            break;
                        }
                    }

                    if (!hasUsedLocal)
                    {
                        nodesToRemove.Add(candidate);
                        foreach (var variable in candidate.Declaration.Variables)
                        {
                            nodesToRemove.Remove(variable);
                        }
                    }
                }

                nodesToRemoveMap.Add(document, nodesToRemove);
            }

            Solution newSolution = _solution;

            foreach (KeyValuePair<Document, HashSet<SyntaxNode>> pair in nodesToRemoveMap)
            {
                var document = pair.Key;
                var root = await document.GetSyntaxRootAsync(cancellationToken).ConfigureAwait(false);
                var syntaxGenerator = SyntaxGenerator.GetGenerator(document);
                var newRoot = syntaxGenerator.RemoveNodes(root, pair.Value);
                newSolution = newSolution.WithDocumentSyntaxRoot(document.Id, newRoot);
            }

            return newSolution;
        }
    }
}