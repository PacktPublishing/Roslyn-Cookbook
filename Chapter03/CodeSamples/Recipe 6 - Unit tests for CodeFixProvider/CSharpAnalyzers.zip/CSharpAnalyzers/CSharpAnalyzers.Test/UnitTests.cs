﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CodeFixes;
using Microsoft.CodeAnalysis.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using TestHelper;
using CSharpAnalyzers;

namespace CSharpAnalyzers.Test
{
    [TestClass]
    public class UnitTest : CodeFixVerifier
    {
        //Diagnostic and CodeFix both triggered and checked for
        [TestMethod]
        public void TestMethod2()
        {
            var test = @"
    namespace ConsoleApplication1
    {
        class TypeName
        {
            class TypeName2
            {
            }
        }
    }";
            var expected = new[] {
                new DiagnosticResult
                {
                    Id = "CSharpAnalyzers",
                    Message = String.Format("Type name '{0}' contains lowercase letters", "TypeName"),
                    Severity = DiagnosticSeverity.Warning,
                    Locations =
                        new[] {
                                new DiagnosticResultLocation("Test0.cs", 4, 15)
                            }
                },
                new DiagnosticResult
                {
                    Id = "CSharpAnalyzers",
                    Message = String.Format("Type name '{0}' contains lowercase letters", "TypeName2"),
                    Severity = DiagnosticSeverity.Warning,
                    Locations =
                        new[] {
                                new DiagnosticResultLocation("Test0.cs", 6, 19)
                            }
                }};

            VerifyCSharpDiagnostic(test, expected);

            var fixtest = @"
    namespace ConsoleApplication1
    {
        class TYPENAME
        {
            class TYPENAME2
            {
            }
        }
    }";
            VerifyCSharpFix(test, fixtest);
        }

        protected override CodeFixProvider GetCSharpCodeFixProvider()
        {
            return new CSharpAnalyzersCodeFixProvider();
        }

        protected override DiagnosticAnalyzer GetCSharpDiagnosticAnalyzer()
        {
            return new CSharpAnalyzersAnalyzer();
        }
    }
}