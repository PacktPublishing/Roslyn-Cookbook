﻿using System.Collections.Immutable;
using System.Composition;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CodeFixes;
using Microsoft.CodeAnalysis.CodeActions;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Editing;

namespace CSharpAnalyzers
{
    [ExportCodeFixProvider(LanguageNames.CSharp, Name = nameof(CSharpAnalyzersCodeFixProvider)), Shared]
    public class CSharpAnalyzersCodeFixProvider : CodeFixProvider
    {
        private const string title = "Remove unused local";

        public sealed override ImmutableArray<string> FixableDiagnosticIds
        {
            get { return ImmutableArray.Create("CS0219"); }
        }

        public sealed override FixAllProvider GetFixAllProvider()
        {
            // See https://github.com/dotnet/roslyn/blob/master/docs/analyzers/FixAllProvider.md for more information on Fix All Providers
            return WellKnownFixAllProviders.BatchFixer;
        }

        public sealed override async Task RegisterCodeFixesAsync(CodeFixContext context)
        {
            var diagnostic = context.Diagnostics.First();

            // Get syntax node to remove for the unused local.
            var nodeToRemove = await GetNodeToRemoveAsync(context.Document, diagnostic, context.CancellationToken).ConfigureAwait(false);
            if (nodeToRemove == null)
            {
                return;
            }

            // Register a code action that will invoke the fix.
            var root = await context.Document.GetSyntaxRootAsync(context.CancellationToken).ConfigureAwait(false);
            context.RegisterCodeFix(
                CodeAction.Create(
                    title: title,
                    createChangedDocument: c => RemoveDeclarationAsync(context.Document, root, nodeToRemove, c),
                    equivalenceKey: title),
                diagnostic);
        }

        private async Task<SyntaxNode> GetNodeToRemoveAsync(Document document, Diagnostic diagnostic, CancellationToken cancellationToken)
        {
            var root = await document.GetSyntaxRootAsync(cancellationToken).ConfigureAwait(false);
            var diagnosticSpan = diagnostic.Location.SourceSpan;

            // Find the variable declarator identified by the diagnostic.
            var variableDeclarator = root.FindToken(diagnosticSpan.Start).Parent.AncestorsAndSelf().OfType<VariableDeclaratorSyntax>().First();
            if (variableDeclarator == null)
            {
                return null;
            }

            // Bail out if the initializer is non-constant (could have side effects if removed).
            if (variableDeclarator.Initializer != null)
            {
                var semanticModel = await document.GetSemanticModelAsync(cancellationToken).ConfigureAwait(false);
                if (!semanticModel.GetConstantValue(variableDeclarator.Initializer.Value).HasValue)
                {
                    return null;
                }
            }

            // Bail out for code with syntax errors - parent of a declaration is not a local declaration statement.
            var variableDeclaration = variableDeclarator.Parent as VariableDeclarationSyntax;
            var localDeclaration = variableDeclaration?.Parent as LocalDeclarationStatementSyntax;
            if (localDeclaration == null)
            {
                return null;
            }

            // If the statement declares a single variable, the code fix should remove the whole statement.
            // Otherwise, the code fix should remove only this variable declaration.
            SyntaxNode nodeToRemove;
            if (variableDeclaration.Variables.Count == 1)
            {
                if (!(localDeclaration.Parent is BlockSyntax))
                {
                    // Bail out for error case where local declaration is not embedded in a block.
                    // Compiler generates errors CS1023 (Embedded statement cannot be a declaration or labeled statement)
                    return null;
                }

                nodeToRemove = localDeclaration;
            }
            else
            {
                nodeToRemove = variableDeclarator;
            }

            return nodeToRemove;
        }

        private Task<Document> RemoveDeclarationAsync(Document document, SyntaxNode root, SyntaxNode declaration, CancellationToken cancellationToken)
        {
            var syntaxGenerator = SyntaxGenerator.GetGenerator(document);
            var newRoot = syntaxGenerator.RemoveNode(root, declaration);
            return Task.FromResult(document.WithSyntaxRoot(newRoot));
        }
    }
}