// Class with no accessibility modifier
class C1
{
  void M() {}
}

// Public class with no documentation comments
public class C2
{
  void M() {}
}

// Empty class with no members
public class C3
{
}