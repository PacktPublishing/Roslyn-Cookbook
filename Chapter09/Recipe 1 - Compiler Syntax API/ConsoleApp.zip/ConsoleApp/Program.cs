﻿using System;
using System.IO;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace ConsoleApp
{
    class Program
    {
        public static void Main(string[] args)
        {
            // Parse arguments to get source file.
            var filePath = ParseArguments(args);
            if (filePath == null)
            {
                return;
            }

            // Parse text into SyntaxTree.
            var tree = Parse(filePath);
            var root = (CompilationUnitSyntax)tree.GetRoot();

            // Transform syntax tree to edit/add/remove syntax.
            root = EditClassDeclarations(root);
            root = AddDocCommentsToClassDeclarations(root);
            root = RemoveEmptyClassDeclarations(root);

            Console.WriteLine("Transformed source:" + Environment.NewLine);
            Console.WriteLine(root.ToFullString());
        }

        private static string ParseArguments(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine(@"Usage: ConsoleApp.exe <%file_path%>");
                return null;
            }

            if (!File.Exists(args[0]))
            {
                Console.WriteLine($"File '{args[0]}' does not exist");
                return null;
            }

            return args[0];
        }

        private static SyntaxTree Parse(string filePath)
        {
            var text = File.ReadAllText(filePath);
            return CSharpSyntaxTree.ParseText(text);
        }

        private static CompilationUnitSyntax EditClassDeclarations(CompilationUnitSyntax root)
        {
            // Get class declarations with no accessibility modifier.
            var classDeclarations = root.DescendantNodes()
                .OfType<ClassDeclarationSyntax>()
                .Where(c => !c.Modifiers.Any(m => SyntaxFacts.IsAccessibilityModifier(m.Kind())));

            // Add modifier to these class declarations and replace in the original tree.
            return root.ReplaceNodes(classDeclarations,
                computeReplacementNode: (o, n) => AddModifier(n));
        }

        private static ClassDeclarationSyntax AddModifier(ClassDeclarationSyntax classDeclaration)
        {
            var internalModifier = SyntaxFactory.Token(SyntaxKind.InternalKeyword)
                .WithTrailingTrivia(SyntaxFactory.Whitespace(" "));
            if (classDeclaration.HasLeadingTrivia)
            {
                // Move leading trivia for the class declaration to the new modifier.
                internalModifier = internalModifier.WithLeadingTrivia(classDeclaration.GetLeadingTrivia());
                classDeclaration = classDeclaration.WithLeadingTrivia();
            }

            var newModifiers = classDeclaration.Modifiers.Insert(0, internalModifier);
            return classDeclaration.WithModifiers(newModifiers);
        }

        private static CompilationUnitSyntax AddDocCommentsToClassDeclarations(CompilationUnitSyntax root)
        {
            // Get public class declarations with no documentation comments.
            var classDeclarations = root.DescendantNodes()
                .OfType<ClassDeclarationSyntax>()
                .Where(c => c.Modifiers.Any(m => m.Kind() == SyntaxKind.PublicKeyword) &&
                    !c.GetFirstToken().LeadingTrivia.Any(IsDocumentationComment));

            // Add stub documentation comment to these class declarations and replace in the original tree.
            return root.ReplaceNodes(classDeclarations,
                computeReplacementNode: (o, n) => AddDocumentationComment(n));
        }

        private static bool IsDocumentationComment(SyntaxTrivia trivia)
        {
            switch (trivia.Kind())
            {
                case SyntaxKind.SingleLineDocumentationCommentTrivia:
                case SyntaxKind.MultiLineDocumentationCommentTrivia:
                    return true;

                default:
                    return false;
            }
        }

        private static ClassDeclarationSyntax AddDocumentationComment(ClassDeclarationSyntax classDeclaration)
        {
            var summaryElement = SyntaxFactory.XmlSummaryElement(SyntaxFactory.XmlText("TODO: Add doc comments"));
            var documentationComment = SyntaxFactory.DocumentationComment(summaryElement);
            var newLeadingTrivia = classDeclaration.GetLeadingTrivia()
                .Add(SyntaxFactory.Trivia(documentationComment))
                .Add(SyntaxFactory.EndOfLine(Environment.NewLine));
            return classDeclaration.WithLeadingTrivia(newLeadingTrivia);
        }

        private static CompilationUnitSyntax RemoveEmptyClassDeclarations(CompilationUnitSyntax root)
        {
            // Get class declarations with no members.
            var classDeclarations = root.DescendantNodes()
                .OfType<ClassDeclarationSyntax>()
                .Where(c => c.Members.Count == 0);

            // Remove these class declarations from the original tree.
            return root.RemoveNodes(classDeclarations, SyntaxRemoveOptions.KeepNoTrivia);
        }
    }
}
