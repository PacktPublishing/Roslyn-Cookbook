class C1
{
  void F()
  {
    M1();
    M2(0);
    M2(null);
  }

  void M1()
  {
  }

  void M2()
  {
  }

  void M2(int x)
  {
  }
}