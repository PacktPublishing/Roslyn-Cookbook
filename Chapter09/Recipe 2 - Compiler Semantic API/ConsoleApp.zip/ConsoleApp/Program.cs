﻿using System;
using System.IO;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace ConsoleApp
{
    class Program
    {
        public static void Main(string[] args)
        {
            // Parse arguments to get source file.
            var filePath = ParseArguments(args);
            if (filePath == null)
            {
                return;
            }

            // Parse text and create a compilation.
            var compilation = CreateCompilation(filePath);

            // Display diagnostics in the compilation.
            DisplayDiagnostics(compilation);

            // Display semantic information about invocations in the file.
            DisplayInvocations(compilation);
        }

        private static string ParseArguments(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine(@"Usage: ConsoleApp.exe <%file_path%>");
                return null;
            }

            if (!File.Exists(args[0]))
            {
                Console.WriteLine($"File '{args[0]}' does not exist");
                return null;
            }

            return args[0];
        }

        private static Compilation CreateCompilation(string filePath)
        {
            var text = File.ReadAllText(filePath);
            var tree = CSharpSyntaxTree.ParseText(text);
            var systemAssembly = MetadataReference.CreateFromFile(typeof(object).Assembly.Location);
            var options = new CSharpCompilationOptions(outputKind: OutputKind.DynamicallyLinkedLibrary);
            return CSharpCompilation.Create("TestAssembly",
                syntaxTrees: new[] { tree },
                references: new[] { systemAssembly },
                options: options);
        }

        private static void DisplayDiagnostics(Compilation compilation)
        {
            var diagnostics = compilation.GetDiagnostics();
            Console.WriteLine($"Number of diagnostics: {diagnostics.Length}");
            foreach (var diagnostic in diagnostics)
            {
                Console.WriteLine(diagnostic.ToString());
            }

            Console.WriteLine();
        }

        private static void DisplayInvocations(Compilation compilation)
        {
            var tree = compilation.SyntaxTrees.Single();
            var semanticModel = compilation.GetSemanticModel(tree);
            var invocations = tree.GetRoot().DescendantNodes().OfType<InvocationExpressionSyntax>();
            foreach (var invocation in invocations)
            {
                Console.WriteLine($"Invocation: '{invocation.ToString()}'");
                var symbolInfo = semanticModel.GetSymbolInfo(invocation);

                var overloadResolutionResult = symbolInfo.CandidateReason == CandidateReason.None ? "Succeeded" : symbolInfo.CandidateReason.ToString();
                Console.WriteLine($"  Overload resolution result: {overloadResolutionResult}");

                if (symbolInfo.Symbol != null)
                {
                    Console.WriteLine($"  Method Symbol: {symbolInfo.Symbol.ToDisplayString(SymbolDisplayFormat.MinimallyQualifiedFormat)}");
                }
                else if (!symbolInfo.CandidateSymbols.IsDefaultOrEmpty)
                {
                    Console.WriteLine($"  {symbolInfo.CandidateSymbols.Length} candidate symbols:");
                    foreach (var candidate in symbolInfo.CandidateSymbols)
                    {
                        Console.WriteLine($"    Candidate Symbol: {candidate.ToDisplayString(SymbolDisplayFormat.MinimallyQualifiedFormat)}");
                    }
                }

                Console.WriteLine();
            }
        }
    }
}
