﻿using System;
using System.IO;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.MSBuild;

namespace ConsoleApp
{
    class Program
    {
        public static void Main(string[] args)
        {
            // Parse arguments to get solution.
            string slnPath = ParseArguments(args);
            if (slnPath == null)
            {
                return;
            }

            // Create workspace.
            MSBuildWorkspace workspace = MSBuildWorkspace.Create();

            // Open solution within the workspace.
            Console.WriteLine($"Loading solution '{slnPath}'...");
            Solution solution = workspace.OpenSolutionAsync(slnPath).Result;

            // Display project properties.
            DisplayProjectProperties(solution);

            // Add project AddedClassLibrary.
            WaitForKeyPress();
            solution = AddProject(solution, "AddedClassLibrary");

            // Remove project ClassLibrary.
            solution = RemoveProject(solution, "ClassLibrary");

            // Add project reference from AddedClassLibrary to TestSolution.
            solution = AddProjectReference(solution, referenceFrom: "AddedClassLibrary", referenceTo: "TestSolution");

            // Display project properties.
            WaitForKeyPress();
            DisplayProjectProperties(solution);
        }

        private static string ParseArguments(string[] args)
        {
            if (args.Length != 1 || !args[0].EndsWith(".sln"))
            {
                Console.WriteLine(@"Usage: ConsoleApp.exe <%solution_file_path%> [add] [remove] [edit]");
                return null;
            }

            if (!File.Exists(args[0]))
            {
                Console.WriteLine($"File '{args[0]}' does not exist");
                return null;
            }

            return args[0];
        }

        private static void WaitForKeyPress()
        {
            Console.WriteLine($"Press any key to continue...");
            Console.ReadKey();
            Console.WriteLine();
        }

        private static void DisplayProjectProperties(Solution solution)
        {
            Console.WriteLine($"Project count: {solution.Projects.Count()}");

            foreach (var project in solution.Projects)
            {
                Console.WriteLine($" Project: {project.Name}");
                Console.WriteLine($"   Assembly name: {project.AssemblyName}");
                Console.WriteLine($"   Language: {project.Language}");
                Console.WriteLine($"   Project file: {project.FilePath}");
                Console.WriteLine($"   Output file: {project.OutputFilePath}");
                Console.WriteLine($"   Documents: {project.Documents.Count()}");
                Console.WriteLine($"   Metadata references: {project.MetadataReferences.Count()}");
                Console.WriteLine($"   Project references: {project.ProjectReferences.Count()}");
                Console.WriteLine();
            }

            Console.WriteLine();
        }

        private static Solution AddProject(Solution originalSolution, string projectName)
        {
            Console.WriteLine($"Adding project '{projectName}'...");
            var projectInfo = ProjectInfo.Create(
                id: ProjectId.CreateNewId(),
                version: new VersionStamp(),
                name: projectName,
                assemblyName: "AddedProjectAssembly",
                language: LanguageNames.CSharp);
            return originalSolution.AddProject(projectInfo);
        }

        private static Solution RemoveProject(Solution originalSolution, string projectName)
        {
            Console.WriteLine($"Removing project '{projectName}'...");
            var project = originalSolution.Projects.SingleOrDefault(p => p.Name == projectName);
            return originalSolution.RemoveProject(project.Id);
        }

        private static Solution AddProjectReference(Solution originalSolution, string referenceFrom, string referenceTo)
        {
            Console.WriteLine($"Adding project reference from '{referenceFrom}' to '{referenceTo}'...");
            var projectReferenceFrom = originalSolution.Projects.SingleOrDefault(p => p.Name == referenceFrom);
            var projectReference = new ProjectReference(projectReferenceFrom.Id);
            var projectReferenceTo = originalSolution.Projects.SingleOrDefault(p => p.Name == referenceTo);
            return originalSolution.AddProjectReference(projectReferenceTo.Id, projectReference);
        }
    }
}
