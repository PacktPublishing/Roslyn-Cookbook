﻿using System;
using System.Collections.Immutable;
using System.IO;
using System.Reflection;
using System.Threading;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.Diagnostics;

namespace ConsoleApp
{
    class Program
    {
        public static void Main(string[] args)
        {
            // Parse arguments to get analyzer assembly file and source file.
            var files = ParseArguments(args);
            if (files.analyzerFile == null || files.sourceFile == null)
            {
                return;
            }

            // Parse source file and create a compilation.
            var compilation = CreateCompilation(files.sourceFile);

            // Create compilation with analyzers.
            var compilationWithAnalyzers = CreateCompilationWithAnalyzers(files.analyzerFile, compilation);

            // Display analyzer diagnostics in the compilation.
            DisplayAnalyzerDiagnostics(compilationWithAnalyzers);
        }

        private static (string analyzerFile, string sourceFile) ParseArguments(string[] args)
        {
            if (args.Length != 2)
            {
                Console.WriteLine(@"Usage: ConsoleApp.exe <%analyzer_file_path%> <%source_file_path%>");
                return (null, null);
            }

            if (!File.Exists(args[0]))
            {
                Console.WriteLine($"Analyzer file '{args[0]}' does not exist");
                return (null, null);
            }

            if (!File.Exists(args[1]))
            {
                Console.WriteLine($"Source file '{args[1]}' does not exist");
                return (null, null);
            }

            return (args[0], args[1]);
        }

        private static Compilation CreateCompilation(string filePath)
        {
            var text = File.ReadAllText(filePath);
            var tree = CSharpSyntaxTree.ParseText(text);
            var systemAssembly = MetadataReference.CreateFromFile(typeof(object).Assembly.Location);
            var options = new CSharpCompilationOptions(outputKind: OutputKind.DynamicallyLinkedLibrary);
            return CSharpCompilation.Create("TestAssembly",
                syntaxTrees: new[] { tree },
                references: new[] { systemAssembly },
                options: options);
        }

        private static CompilationWithAnalyzers CreateCompilationWithAnalyzers(string analyzerFilePath, Compilation compilation)
        {
            var analyzerFileReference = new AnalyzerFileReference(analyzerFilePath, new AnalyzerAssemblyLoader());
            var analyzers = analyzerFileReference.GetAnalyzers(LanguageNames.CSharp);
            var options = new CompilationWithAnalyzersOptions(
                new AnalyzerOptions(ImmutableArray<AdditionalText>.Empty),
                onAnalyzerException: (exception, analyzer, diagnostic) => throw exception,
                concurrentAnalysis: false,
                logAnalyzerExecutionTime: false);
            return new CompilationWithAnalyzers(compilation, analyzers, options);
        }

        private static void DisplayAnalyzerDiagnostics(CompilationWithAnalyzers compilationWithAnalyzers)
        {
            var diagnostics = compilationWithAnalyzers.GetAnalyzerDiagnosticsAsync(CancellationToken.None).Result;
            Console.WriteLine($"Number of diagnostics: {diagnostics.Length}");
            foreach (var diagnostic in diagnostics)
            {
                Console.WriteLine(diagnostic.ToString());
            }

            Console.WriteLine();
        }

        private class AnalyzerAssemblyLoader : IAnalyzerAssemblyLoader
        {
            void IAnalyzerAssemblyLoader.AddDependencyLocation(string fullPath)
            {
            }

            Assembly IAnalyzerAssemblyLoader.LoadFromPath(string fullPath)
            {
                return Assembly.LoadFrom(fullPath);
            }
        }
    }
}
