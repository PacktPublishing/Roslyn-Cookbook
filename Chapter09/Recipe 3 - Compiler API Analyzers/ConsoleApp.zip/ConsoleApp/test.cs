class ClassWithLowerCase
{
}

class OuterClassWithLowerCase
{
  class NestedClassWithLowerCase
  {
  }
}

class CLASS_WITH_UPPER_CASE
{
}