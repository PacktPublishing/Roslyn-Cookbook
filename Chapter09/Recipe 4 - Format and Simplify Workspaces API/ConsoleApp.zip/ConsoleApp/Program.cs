﻿using System;
using System.IO;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.MSBuild;
using Microsoft.CodeAnalysis.Formatting;
using System.Collections.Generic;
using System.Collections.Immutable;
using Microsoft.CodeAnalysis.Simplification;
using Microsoft.CodeAnalysis.Options;

namespace ConsoleApp
{
    class Program
    {
        public static void Main(string[] args)
        {
            // Parse arguments to get solution.
            var slnPath = ParseArguments(args);
            if (slnPath == null)
            {
                return;
            }

            // Create workspace.
            MSBuildWorkspace workspace = MSBuildWorkspace.Create();

            // Open solution within the workspace.
            Console.WriteLine($"Loading solution '{slnPath}'...");
            Solution solution = workspace.OpenSolutionAsync(slnPath).Result;

            // Format the solution.
            solution = FormatSolution(solution, workspace.Options);

            // Simplify the solution.
            solution = SimplifySolution(solution, workspace.Options);

            // Apply changes.
            ApplyChanges(workspace, solution);
        }

        private static string ParseArguments(string[] args)
        {
            if (args.Length != 1 || !args[0].EndsWith(".sln"))
            {
                Console.WriteLine(@"Usage: ConsoleApp.exe <%solution_file_path%>");
                return null;
            }

            if (!File.Exists(args[0]))
            {
                Console.WriteLine($"File '{args[0]}' does not exist");
                return null;
            }

            return args[0];
        }

        private static Solution FormatSolution(Solution originalSolution, OptionSet options)
        {
            Console.WriteLine("Formatting solution...");

            // Prefer whitespaces over tabs, with an indentation size of 2.
            options = options
                .WithChangedOption(FormattingOptions.UseTabs, LanguageNames.CSharp, false)
                .WithChangedOption(FormattingOptions.IndentationSize, LanguageNames.CSharp, 2);

            Solution newSolution = originalSolution;
            foreach (var documentId in originalSolution.Projects.SelectMany(p => p.DocumentIds))
            {
                Document document = newSolution.GetDocument(documentId);

                // Format the document.
                Document newDocument = Formatter.FormatAsync(document, options).Result;

                // Update the current solution.
                newSolution = newDocument.Project.Solution;
            }

            return newSolution;
        }

        private static Solution SimplifySolution(Solution originalSolution, OptionSet options)
        {
            Console.WriteLine("Simplifying solution...");

            // Prefer 'var' over explicit type specification.
            options = options.WithChangedOption(SimplificationOptions.PreferImplicitTypeInLocalDeclaration, true);

            Solution newSolution = originalSolution;
            foreach (var documentId in originalSolution.Projects.SelectMany(p => p.DocumentIds))
            {
                Document document = newSolution.GetDocument(documentId);

                // Add simplification annotation to the root.
                var newRoot = document.GetSyntaxRootAsync().Result.WithAdditionalAnnotations(Simplifier.Annotation);
                
                // Simplify the document.
                Document newDocument = Simplifier.ReduceAsync(document.WithSyntaxRoot(newRoot), options).Result;

                // Update the current solution.
                newSolution = newDocument.Project.Solution;
            }

            return newSolution;
        }

        private static void ApplyChanges(Workspace workspace, Solution solution)
        {
            // Apply solution changes to the workspace.
            // This persists the in-memory changes into the disk.
            if (workspace.TryApplyChanges(solution))
            {
                Console.WriteLine("Solution updated.");
            }
            else
            {
                Console.WriteLine("Update failed!");
            }
        }
    }
}
