﻿namespace TestSolution
{
  class Program
  {
    static void Main(string[] args)
    {
      var implicitlyTypedLocal = 0;
      var explicitlyTypedLocal = 1;
    }
  }
}