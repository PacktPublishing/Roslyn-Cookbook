﻿using System.Data.Linq;
using System.Data.SqlClient;
using System.DirectoryServices;

public class Class1
{
    private void SQL_Injection(SqlConnection connection, string id)
    {
        using (DataContext context = new DataContext(connection))
        {
            context.ExecuteCommand("SELECT * FROM Items WHERE ID = " + id);
        }

        SqlCommand cmd = new SqlCommand("SELECT * FROM Items WHERE ID = " + id, connection);
        string result = cmd.ExecuteScalar().ToString();
    }

    private void LDAP_Injection(string domain, string userName)
    {
        DirectoryEntry entry = new DirectoryEntry(string.Format("LDAP://DC={0}, DC=COM/", domain));
        DirectorySearcher searcher = new DirectorySearcher(entry)
        {
            SearchScope = SearchScope.Subtree,
            Filter = string.Format("(name={0})", userName)
        };
        SearchResultCollection resultCollection = searcher.FindAll();
    }
}