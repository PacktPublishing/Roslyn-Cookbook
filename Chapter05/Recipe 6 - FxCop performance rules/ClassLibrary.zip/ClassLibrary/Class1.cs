﻿using System;

namespace Namespace
{
    public class Class1: IDisposable
    {
        private static int staticField;
        private int[,] multiDimArray;
        
        static Class1()
        {
            staticField = 3;
        }

        public void Method1(int usedParam, int unusedParam)
        {
            Console.WriteLine(usedParam);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(true);  // Violates rule
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Dispose resources.
            }
        }

        ~Class1()
        {
        }
    }

    public struct ValueType
    {
        public int Property { get; }
    }
}