﻿using System.Web.UI;

namespace WebApplication.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}