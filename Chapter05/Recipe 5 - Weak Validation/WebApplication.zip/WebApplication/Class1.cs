﻿using System.Configuration;
using System.Net.Http;
using System.Web.Mvc;

namespace WebApplication
{
    public class Class1
    {
        [AllowHtml]
        public string AllowHtmlProperty { get; set; }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Missing_AntiForgeryToken()
        {
            return null;
        }

        [HttpPost]
        public FileResult Path_Tampering(string fileName)
        {
            string filePath = ConfigurationManager.AppSettings["DownloadDirectory"].ToString();
            return new FilePathResult(filePath + fileName, "application/octet-stream");
        }

        private void Certificate_Validation_Disabled()
        {
            using (var handler = new WebRequestHandler())
            {
                handler.ServerCertificateValidationCallback += (sender, cert, chain, sslPolicyErrors) => true;
            }
        }
    }
}