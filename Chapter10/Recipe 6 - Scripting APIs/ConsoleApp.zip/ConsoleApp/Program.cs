﻿using System;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis.CSharp.Scripting;
using Microsoft.CodeAnalysis.Scripting;

namespace ConsoleApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            EvaluateSimpleAsync().Wait();

            Console.ReadKey();
            EvaluateWithReferencesAsync().Wait();

            Console.ReadKey();
            EvaluateWithImportsAsync().Wait();

            Console.ReadKey();
            EvaluateParameterizedScriptInLoopAsync().Wait();
        }

        private static async Task EvaluateSimpleAsync()
        {
            Console.WriteLine("Executing EvaluateSimpleAsync...");
            object result = await CSharpScript.EvaluateAsync("1 + 2");
            Console.WriteLine(result);
        }

        private static async Task EvaluateWithReferencesAsync()
        {
            Console.WriteLine("Executing EvaluateWithReferencesAsync...");
            var result = await CSharpScript.EvaluateAsync("System.Net.Dns.GetHostName()",
                ScriptOptions.Default.WithReferences(typeof(System.Net.Dns).Assembly));
            Console.WriteLine(result);
        }

        private static async Task EvaluateWithImportsAsync()
        {
            Console.WriteLine("Executing EvaluateWithImportsAsync...");
            var result = await CSharpScript.EvaluateAsync("Sqrt(2)",
                ScriptOptions.Default.WithImports("System.Math"));
            Console.WriteLine(result);
        }

        private static async Task EvaluateParameterizedScriptInLoopAsync()
        {
            Console.WriteLine("Executing EvaluateParameterizedScriptInLoopAsync...");
            var script = CSharpScript.Create<int>("X*Y", globalsType: typeof(Globals));
            script.Compile();
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine((await script.RunAsync(new Globals { X = i, Y = i })).ReturnValue);
            }
        }
    }

    public class Globals
    {
        public int X;
        public int Y;
    }
}
