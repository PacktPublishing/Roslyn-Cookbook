﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MSTestBasedTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            var c = new ClassLibrary.Class1();
            Assert.IsTrue(c.Method1());
        }

        [TestMethod]
        public void TestMethod2()
        {
            var c = new ClassLibrary.Class1();
            Assert.IsTrue(c.Method2());
        }
    }
}
