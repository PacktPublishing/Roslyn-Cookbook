﻿namespace ClassLibrary
{
    public class Class1
    {
        public bool Method1()
        {
            return false;
        }

        public bool Method2()
        {
            return true;
        }

        public bool Method3(Class1 c)
        {
            return c.Method1();
        }

        public bool Method4(Class1 c)
        {
            return c.Method2();
        }
    }
}