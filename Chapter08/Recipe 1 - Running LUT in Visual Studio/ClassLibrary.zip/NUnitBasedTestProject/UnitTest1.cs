﻿using NUnit.Framework;

namespace NUnitBasedTestProject
{
    [TestFixture]
    public class UnitTest1
    {
        [Test]
        public void TestMethod1()
        {
            var c = new ClassLibrary.Class1();
            Assert.True(c.Method1());
        }

        [Test]
        public void TestMethod2()
        {
            var c = new ClassLibrary.Class1();
            Assert.True(c.Method2());
        }
    }
}
