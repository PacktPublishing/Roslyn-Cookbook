﻿using Xunit;

namespace XUnitBasedTestProject
{
    public class UnitTest1
    {
        [Fact]
        public void TestMethod1()
        {
            var c = new ClassLibrary.Class1();
            Assert.True(c.Method1());
        }

        [Fact]
        public void TestMethod2()
        {
            var c = new ClassLibrary.Class1();
            Assert.True(c.Method2());
        }
    }
}
