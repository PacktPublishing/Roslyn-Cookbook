﻿namespace ClassLibrary
{
    public class Class2
    {
        public bool Method5()
        {
            return false;
        }

        public bool Method6()
        {
            return true;
        }
    }
}