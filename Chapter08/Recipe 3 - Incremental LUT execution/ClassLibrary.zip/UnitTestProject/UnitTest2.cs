﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MSTestBasedTestProject
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void TestMethod5()
        {
            var c = new ClassLibrary.Class2();
            Assert.IsTrue(c.Method5());
        }

        [TestMethod]
        public void TestMethod6()
        {
            var c = new ClassLibrary.Class2();
            Assert.IsTrue(c.Method6());
        }
    }
}
