﻿Public Class Class1
    Public Sub Method()
        Console.Write("Hello World!")
    End Sub
End Class
