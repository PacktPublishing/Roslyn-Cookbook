﻿using System;

namespace ClassLibrary
{
    public class Class1
    {
        public static void Method()
        {
            Console.WriteLine("Hello world!");
        }
    }
}
