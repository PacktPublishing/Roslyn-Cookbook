﻿using System;

namespace ClassLibrary
{
    [AttributeUsage(AttributeTargets.All)]
    public class MyAttribute : Attribute
    {
    }
}