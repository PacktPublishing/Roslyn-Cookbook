﻿using System;

namespace Namespace
{
    public class Class1
    {
        private void Method1() { }

        private void Method2(bool flag)
        {

            if (flag)
                Console.WriteLine("True");
        }
    }

    /// <summary>
    /// Document class
    /// </summary>
    public class Class2
    {
        /// <summary>
        /// public field
        /// </summary>
        public int PublicField;

        private const int privateConstant = 0;

        private int method()
        {
            return  PublicField;
        }
    }
}