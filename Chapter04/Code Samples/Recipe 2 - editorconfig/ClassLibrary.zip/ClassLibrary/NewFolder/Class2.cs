﻿class Class2
{
    private void Method_New_ViolateVarPreference()
    {
        var c = new Class1();
    }
}