﻿public class Class1
{
    public int Field1;

    public object Property1 => null;

    public void Method1() { }

    public void Method1(int x) { }

    private void Method2() { }
}