﻿using System;

class Class1
{
    // Field and Property - prefer predefined type
    private System.Int32 field1;
    private System.Int32 Property1 => System.Int32.MaxValue;

    private void Method_DoNotPreferThis()
    {
        Console.WriteLine(this.field1);
        Console.WriteLine(this.Property1);
        this.Method_PreferExpressionBody();
    }

    private int Method_PreferVar()
    {
        int i = 0;
        Class1 c = new Class1();
        Class1 c2 = Method_PreferExpressionBody();
        return i;
    }

    private void Method_PreferBraces(bool flag)
    {
        if (flag)
            Console.WriteLine(flag);
    }

    private Class1 Method_PreferExpressionBody()
    {
        return Method_PreferPatternMatching(null);
    }

    private Class1 Method_PreferPatternMatching(object o)
    {
        if (o is Class1)
        {
            var c = (Class1)o;
            return c;
        }

        return new Class1();
    }

    private int Method_PreferInlineVariableDeclaration(string s)
    {
        int i;
        if (int.TryParse(s, out i))
        {
            return i;
        }

        return -1;
    }

    private void Method_NullCheckingPreferences(object o)
    {
        var str = o != null ? o.ToString() : null;
        var o3 = o != null ? o : new object();
    }
}